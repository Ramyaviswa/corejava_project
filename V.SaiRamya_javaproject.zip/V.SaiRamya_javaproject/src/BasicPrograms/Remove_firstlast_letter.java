package BasicPrograms;

public class Remove_firstlast_letter
{
	public static String
	Remove_fristLast_letter(String str)
	{
		str =str.substring(1, str.length()-1);
		return str;
	}

	public static void main(String[] args)
	{
		String str = "Edubridge";
		System.out.print(Remove_fristLast_letter(str));

	}

}
