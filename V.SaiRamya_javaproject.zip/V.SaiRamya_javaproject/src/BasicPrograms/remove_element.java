package BasicPrograms;
import java.util.Arrays;

class remove_element
{
	public static double[] removeTheElement(double[] arr, double index)
	
	{
		if (arr == null || index < 0 || index >= arr.length) {

			return arr;
		}
		double[] anotherArray = new double[arr.length - 1];
		for (int i = 0, k = 0; i < arr.length; i++)
		{
			if (i == index) 
			{
				continue;
			}
			anotherArray[k++] = arr[i];
		}
		return anotherArray;
	}
	public static void main(String[] args)
	{
		double[] arr = { 1, 3, 4, 5, 6, 7.9, 8, 9.9, 10 };
		System.out.println("Original Array: "+ Arrays.toString(arr));
		double index = 5;
		System.out.println("Index to be removed: " + index);
		double index1 = 5;
		System.out.println("Index to be removed: " + index1);
		arr = removeTheElement(arr, index);
		arr = removeTheElement(arr, index1);
		System.out.println("Resultant Array: "+ Arrays.toString(arr));
	}
}

