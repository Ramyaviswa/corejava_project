package BasicPrograms;

public class ReverseString
{

	public static void main(String[] args)
	{
		String string = "Java Program";
		String reversedStr="";
		
		for(int i = string.length()-1;i>=0;i--)
		{
			reversedStr=reversedStr+string.charAt(i); 
		}
		System.out.print("String:"+string);
		System.out.println("Reverse of given string:"+reversedStr);
	}

}
